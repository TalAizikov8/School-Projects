#Tal Aizikov     101150420
#This will display a calculation and solve it

print("Do you want to know what (2.019x10^-9 x 5.76x10^-7) / (7.16x10^-4 + 9.23x10^-7)") #getting user engaged
num = ((2.019*(10^-9) * 5.76*(10^-7)) / (7.16*(10^-4) + 9.23*(10^-7))) #Calculating what it is 
#The line above is not neccesary but it makes the program look more organized

print("It is "+ str(num)) #printing it out

