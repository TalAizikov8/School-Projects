name = 'John'
name.ljust(15)
print (name.ljust(15) + "tt")