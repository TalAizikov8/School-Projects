import random
list = ['a','b','3','d','e']

sum = 0
sum = int(list[2])
print(sum+4)